// PREP we need to make an onlick event when the buttons are clicked
//
let button1 = document.getElementById('Rock')
let button2 = document.getElementById('paper')
let button3 = document.getElementById('Scissors')
let button4 = document.getElementById('Lizard')
let button5 = document.getElementById('Spock')
